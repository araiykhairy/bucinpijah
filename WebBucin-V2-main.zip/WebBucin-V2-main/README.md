# WebBucin-V2
Web Bucin V2 khusus buat orang tercinta &amp; tersayang.

# Demo Site
 <a href="https://wafarifki.github.io/WebBucin-V2/">https://wafarifki.github.io/WebBucin-V2/</a>

# Let's connect with me!
<p>
    <a href="https://wafarifki.tk" target="_blank"><img src="https://img.shields.io/badge/Website-https://wafarifki.tk-blue?" /></a>
    <a href="https://www.linkedin.com/in/wafa-rifqi-anafin-553b591b7/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-WafaRifkiAnafin_-blue" /></a>
    <a href="https://facebook.com/wafarifkianafin" target="_blank"><img src="https://img.shields.io/badge/Facebook-wafarifkianafin-blue" /></a>
    <a href="https://instagram.com/wafarifki_" target="_blank"><img src="https://img.shields.io/badge/Instagram-@wafarifki_-blue" /></a>
</p> 
# WebBucin-V2
Web Bucin V2 khusus buat orang tercinta &amp; tersayang.

# Demo Site
 <a href="https://wafarifki.github.io/WebBucin-V2/">https://wafarifki.github.io/WebBucin-V2/</a>

# Let's connect with me!
<p>
    <a href="https://wafarifqi.com" target="_blank"><img src="https://img.shields.io/badge/Website-https://wafarifqi.com-blue?" /></a>
    <a href="https://www.linkedin.com/in/wafa-rifqi-anafin-553b591b7/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-WafaRifkiAnafin_-blue" /></a>
    <a href="https://facebook.com/wafarifkianafin" target="_blank"><img src="https://img.shields.io/badge/Facebook-wafarifkianafin-blue" /></a>
    <a href="https://instagram.com/wafarifki_" target="_blank"><img src="https://img.shields.io/badge/Instagram-@wafarifki_-blue" /></a>
</p> 
